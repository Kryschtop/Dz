
    package sample;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

    public class Controller2 {

        @FXML
        private ResourceBundle resources;

        @FXML
        private URL location;

        @FXML
        private Button myButton;

        @FXML
        private Label myLabel;

        @FXML
        private TextField nameField;

        @FXML
        void initialize() {
            assert myButton != null : "fx:id=\"myButton\" was not injected: check your FXML file 'Avto.fxml'.";
            assert myLabel != null : "fx:id=\"myLabel\" was not injected: check your FXML file 'Avto.fxml'.";
            assert nameField != null : "fx:id=\"nameField\" was not injected: check your FXML file 'Avto.fxml'.";

        }
    }

