package sample.DataBase;




    public class Config {
        protected String HOST="jdbc:mysql://server222.hosting.reg.ru/u0613437_easyit?useUnicode=true&serverTimezone=UTC";
        protected String USER="u0613437_easyit";
        protected String PASS="Test1234";


    }




