package sample.web;

public class Main {

    public static void main(String[] args) {
        new Server();
	// write your code here
    }
}
